<?php

namespace tests\codeception\common\fixtures;

use yii\test\ActiveFixture;

/**
 * User fixture
 */
class PostFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Post';
}
